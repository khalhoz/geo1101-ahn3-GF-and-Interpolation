import laspy
import numpy as np
from sklearn.metrics import f1_score, confusion_matrix, classification_report
from tabulate import tabulate


def get_labels(file): 
    pc = laspy.file.File(file, mode='r')
    return pc.classification


def f1score(true_labels, predicted_labels, file):
    obj = open(file, 'w')
    
    for i in range(len(true_labels)):
        if true_labels[i] != 2:
            true_labels[i] = 0
    for i in range(len(predicted_labels)):
        if predicted_labels[i] != 2:
            predicted_labels[i] = 0

    con_matrix = confusion_matrix(true_labels, predicted_labels,[2,0])
    class_report = classification_report(true_labels, predicted_labels)

    table = [ ["", "Actual ground points", "Actual non-ground points"], 
            ["Predicted ground points", con_matrix[0][0], con_matrix[0][1]], 
            ["Predicted non-ground points", con_matrix[1][0], con_matrix[1][1]] ]
    
    s1 = f1_score(true_labels, predicted_labels, average=None)[1]
    s2 = f1_score(true_labels, predicted_labels, average='macro')
    s3 = f1_score(true_labels, predicted_labels, average='micro')
    s4 = f1_score(true_labels, predicted_labels, average='weighted')
    
    obj.write("Confusion matrix\n")
    obj.write(tabulate(table))
    obj.write("\n\nF1-score = " + str(s1) + "\n")
    obj.write("macro F1-score = " + str(s2) + "\n")
    obj.write("micro F1-score = " + str(s3) + "\n")
    obj.write("weighted F1-score = " + str(s4))
    obj.write("\n\nOverall results table\n")
    obj.write("-------------------------------------\n\n")
    obj.write(class_report)

    obj.close()
    return


if __name__ == '__main__':
    true_labels_ams = get_labels("true_labels/Amsterdam_manually_classified.las")
    true_labels_del = get_labels("true_labels/Delft_manually_classified.las")
    true_labels_bie = get_labels("true_labels/Biesbosch_manually_classified.las")
    gf_methods = ["_AHN", "_lasground"] #, "_PDAL_smrf", "_PDAL_pmf", "_CSF"]

    for method in gf_methods:
        predicted_labels_ams = get_labels(method[1:] + "/Amsterdam" + method + ".las")
        predicted_labels_del = get_labels(method[1:] + "/Delft" + method + ".las")
        predicted_labels_bie = get_labels(method[1:] + "/Biesbosch" + method + ".las")

        f1score(true_labels_ams, predicted_labels_ams, method[1:] + "/Amsterdam" + method + "_report.txt")
        f1score(true_labels_del, predicted_labels_del, method[1:] + "/Delft" + method + "_report.txt")
        f1score(true_labels_bie, predicted_labels_bie, method[1:] + "/Biesbosch" + method + "_report.txt")